<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Мария Бобровская</title>
	<title>Подарки для Мария Бобровская - стр 1</title>
	<meta name="description" content="mariabobrovskaya">
	<meta name="keywords" content="mariabobrovskaya">
	<link rel="stylesheet" href="style.css"> 
</head>
<body>

<div class="content">
	<?php>
		include "menu.php"
	?>

	<h1>Личный сайт Марии Бобровской</h1>

	<div class="center">
	<img src="img/5jbvd74hEvE.jpg">
		<div class="box_text">
			<p>Добрый день. Это сайт <a href=""><b>Марии Бобровской.</b></a></p> Самой лучшей девушки на свете, самой искренней и нежной, самой замечательной и любимой!.</p>

			<p>В этом мне помог мой парень <a href="https://www.instagram.com/kirill_by_777/">Кирилл</a></p>

			<p>На этом сайте, Мария Алексеевна, вы можете увидеть разделы: <br>
			<a href="wishes.html">Поздравление С Днем Рождения,</a><br>
			<a href="way.html">Цель,</a><br>
			<a href="getPresent.html">Получить подарок</a><br>
			</p>
		</div>
	</div>
</div>
<div class="footer">
	Copyright &copy; Maria Bobrovskaya
<div>


</body>
</html>