<div class="header">
	<a href="wishes.html">Поздравление С Днем Рождения</a>
	<a href="way.html">Цель</a>
	<a href="getPresent.html">Получить подарок</a>
	<a href="riddle.html">Игра в загадки</a>
	<a href="generatePass.html">Генерация пароля</a>
</div>